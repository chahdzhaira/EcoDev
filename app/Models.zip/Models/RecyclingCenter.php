<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RecyclingCenter extends Model
{
    use HasFactory;
    protected $fillable = [
        'image',
        'name',
        'address',
        'phoneNumber',
        'email',
        'manager_name',
        'opening_hours',
        'closing_hours',
    ];
    public function distributions()
    {
        return $this->hasMany(Distribution::class); 
    }
}
